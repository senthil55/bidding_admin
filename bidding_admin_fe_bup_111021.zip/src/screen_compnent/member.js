import React, { useState } from "react";
import BodyTopbar from "../compnent/body_topbar";
import MemberDetailsPopup from "../compnent/member_det_popup";
import MyTable from "../compnent/table";
import { rejectAprovel, updateMember } from "../methord/member";

function Member({
  memActive,
  memActiveT,
  memNotActive,
  memNotActiveT,
  memBlock,
  memBlockT,
  setpage,
  page,
  searchA,
  searchD,
  searchB,
  reload,
}) {
  const titles = [
    { title: "All Members", count: memActive.length },
    { title: "New Request", count: memNotActive.length },
    { title: "Blocked Members", count: memBlock.length },
  ];

  console.log(memActive);

  return (
    <React.StrictMode>
      <div className="cm1_page_title">Vendor</div>
      <BodyTopbar titles={titles} onclick={setpage} />
      {page === 0 ? (
        <AllMember
          items={memActive}
          itemsT={memActiveT}
          search={searchA}
          reload={reload}
        />
      ) : (
        ""
      )}
      {page === 1 ? (
        <NewRequstes
          items={memNotActive}
          itemsT={memNotActiveT}
          search={searchD}
          reload={reload}
        />
      ) : (
        ""
      )}
      {page === 2 ? (
        <RenewelRequsts
          items={memBlock}
          itemsT={memBlockT}
          search={searchB}
          reload={reload}
        />
      ) : (
        ""
      )}
    </React.StrictMode>
  );
}

export default Member;

function AllMember({ items, itemsT, search, reload }) {
  const [selected, setselected] = useState(null);
  const [updateLoading, setupdateLoading] = useState(false);
  const [updateerror, setupdateerror] = useState("");
  console.log(items);
  return (
    <React.StrictMode>
      <MemberDetailsPopup
        close={() => setselected(null)}
        i={selected}
        members={items}
        error={updateerror}
        buttons={
          <React.StrictMode>
            <div
              className="cm1_mb1_acb"
              style={updateLoading ? { background: "gray" } : {}}
              onClick={async () => {
                if (!updateLoading) {
                  setupdateLoading(true);
                  await updateMember(items[selected], "b", setupdateerror);
                  if (updateerror === "") {
                    reload();
                    setselected(null);
                  }
                  setupdateLoading(false);
                }
              }}
            >
              Block User
            </div>
            {/* <div className="cm1_mb1_acs" onClick={() => setselected(null)}>
              Save
            </div> */}
            <div className="cm1_mb1_acc" onClick={() => setselected(null)}>
              Close
            </div>
          </React.StrictMode>
        }
      />
      <MyTable
        fBody={""}
        search={search}
        title="All Vendor"
        titles={[
          { name: "Person", cl: "tr3" },
          { name: "Location", cl: "tr2" },
          { name: "Phone", cl: "tr2" },
          { name: "Catogery", cl: "tr2" },
        ]}
        onclick={setselected}
        items={itemsT}
      />
    </React.StrictMode>
  );
}

function NewRequstes({ items, itemsT, search, reload }) {
  const [selected, setselected] = useState(null);
  const [updateLoading, setupdateLoading] = useState(false);
  const [updateerror, setupdateerror] = useState("");
  return (
    <React.StrictMode>
      <MemberDetailsPopup
        close={() => setselected(null)}
        i={selected}
        members={items}
        error={updateerror}
        buttons={
          <React.StrictMode>
            <div
              className="cm1_mb1_acs"
              onClick={async () => {
                if (!updateLoading) {
                  setupdateLoading(true);
                  await updateMember(items[selected], "a", setupdateerror);
                  if (updateerror === "") {
                    reload();
                    setselected(null);
                  }
                  setupdateLoading(false);
                }
              }}
            >
              Aprove
            </div>
            <div
              className="cm1_mb1_acb"
              style={updateLoading ? { background: "gray" } : {}}
              onClick={async () => {
                if (!updateLoading)
                  await rejectAprovel(
                    items[selected]._id,
                    setupdateLoading,
                    setupdateerror,
                    () => {
                      reload();
                      setselected(null);
                    }
                  );
              }}
            >
              Reject
            </div>
            <div className="cm1_mb1_acc" onClick={() => setselected(null)}>
              Close
            </div>
          </React.StrictMode>
        }
      />
      <MyTable
        title="New Requstes"
        search={search}
        titles={[
          { name: "Person", cl: "tr3" },
          { name: "Location", cl: "tr2" },
          { name: "Phone", cl: "tr2" },
          { name: "Catogery", cl: "tr2" },
        ]}
        onclick={setselected}
        items={itemsT}
      />
    </React.StrictMode>
  );
}

function RenewelRequsts({ items, itemsT, search, reload }) {
  const [selected, setselected] = useState(null);
  const [updateLoading, setupdateLoading] = useState(false);
  const [updateerror, setupdateerror] = useState("");
  return (
    <React.StrictMode>
      <MemberDetailsPopup
        close={() => setselected(null)}
        i={selected}
        members={items}
        error={updateerror}
        buttons={
          <React.StrictMode>
            <div
              className="cm1_mb1_acb"
              onClick={async () => {
                if (!updateLoading) {
                  setupdateLoading(true);
                  await updateMember(items[selected], "a", setupdateerror);
                  if (updateerror === "") {
                    reload();
                    setselected(null);
                  }
                  setupdateLoading(false);
                }
              }}
            >
              UnBlock User
            </div>
            <div className="cm1_mb1_acc" onClick={() => setselected(null)}>
              Close
            </div>
          </React.StrictMode>
        }
      />
      <MyTable
        title="Blocked Vendor"
        search={search}
        titles={[
          { name: "Person", cl: "tr3" },
          { name: "Location", cl: "tr2" },
          { name: "Phone", cl: "tr2" },
          { name: "Catogery", cl: "tr2" },
        ]}
        onclick={setselected}
        items={itemsT}
      />
    </React.StrictMode>
  );
}
