function Bid(params) {
  return <div>Bid</div>;
}

export default Bid;
