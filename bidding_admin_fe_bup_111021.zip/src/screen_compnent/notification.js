import React from "react";
import { useEffect } from "react";
import BodyTopbar from "../compnent/body_topbar";
import MyTable from "../compnent/table";
import { getNotification } from "../methord/notification";

function Notification({
  notiNew,
  notiNewT,
  notiBids,
  notiBidsT,
  notiMemeber,
  notiMemeberT,
  notiAll,
  notiAllT,
  setpage,
  page,
  setallpage,
}) {
  const titles = [
    {
      title: "New Notification",
      count: notiNew.length,
      item: notiNew,
      itemT: notiNewT,
    },
    {
      title: "Bids Notification",
      count: notiBids.length,
      item: notiBids,
      itemT: notiBidsT,
    },
    {
      title: "Member Notification",
      count: notiMemeber.length,
      item: notiMemeber,
      itemT: notiMemeberT,
    },
    {
      title: "All Notification",
      count: notiAll.length,
      item: notiAll,
      itemT: notiAllT,
    },
  ];

  return (
    <React.StrictMode>
      <div className="cm1_page_title">Notification</div>
      <BodyTopbar titles={titles} onclick={setpage} />

      <MyTable
        fBody={""}
        onclick={(k) => {
          titles[page].item[k].type === "b" ? setallpage(1) : setallpage(2);
        }}
        search={(e) => {}}
        title={titles[page].title}
        titles={[
          { name: "Title", cl: "tr6" },
          { name: "Time", cl: "tr3" },
        ]}
        data={titles[page].item}
        items={titles[page].itemT}
      />
    </React.StrictMode>
  );
}

export default Notification;
