import { api_init_get, api_init_post } from "../module/api_init";

async function getBids(settableItems, setmembers, seterror, v) {
  var items = [];
  await api_init_get("bids?value=" + v, (data) => (items = data), seterror);
  if (items.length > 0) {
    setmembers(items);
    var tableItems = [];
    for (let i = 0; i < items.length; i++) {
      tableItems.push([
        [items[i].title, items[i].desc],
        [items[i].category, items[i].delivery_type],
        [items[i].state, items[i].district],
        [items[i].created.split("G")[0], items[i].created.split("G")[0]],
        [
          items[i].bids.length,
          items[i].status === "u"
            ? "Upcoming"
            : items[i].status === "r"
            ? "Running"
            : "Expired",
        ],
      ]);
    }
    settableItems(tableItems);
  }
  return 0;
}

async function getCatogeryBids(setcatogeries, setloading, seterror) {
  setloading(true);
  var cat = [];
  await api_init_get("category", (v) => (cat = v), seterror);
  setcatogeries([{ id: "-1", title: "All" }, ...cat]);
  setloading(false);
}

async function createBid(
  e,
  setloading,
  seterror,
  hindi,
  tamil,
  malayalam,
  kannada,
  telungu
) {
  e.preventDefault();

  var data = e.target;
  const formData = new FormData();
  if (data.photo.files[0] != null)
    formData.append("img", data.photo.files[0], data.photo.files[0].name);

  function langsetter(t, v) {
    if (v) {
      return {
        status: true,
        title: e.target[t + "B"].value,
        desc: e.target[t + "D"].value,
      };
    } else return { status: false, title: "", desc: "" };
  }
  var body = {
    type: data.type.value,
    category: data.category.value,
    end_date: data.dateE.value,
    start_price: data.priceS.value,
    carry_type: data.trans.value,
    carry_price: data.priceT.value,
    visible_state: data.stateV.value,
    visible_category: data.categoryV.value,
    visible_lag: data.langageV.value,
    state: data.state.value,
    district: data.district.value,
    town: data.town.value,
    pin: data.pin.value,
    title: data.EnglishB.value,
    desc: data.EnglishD.value,
    qty: data.qty.value,
    unit: data.unit.value,
    langages: {
      hindi: langsetter("Hindi", hindi),
      tamil: langsetter("Tamil", tamil),
      malayalam: langsetter("Malayalam", malayalam),
      kannada: langsetter("Kannada", kannada),
      telugu: langsetter("Telugu", telungu),
    },
  };
  formData.append("body", JSON.stringify(body));
  await api_init_post(
    "bids",
    formData,
    () => {
      alert("Succesfully Created");
      document.getElementById("bid_add_form").reset();
    },
    seterror
  );
  setloading();
}

async function confirmBid(id, bid, setloading, seterror, reload) {
  if (window.confirm("Confirm Assigning to " + bid.user_name)) {
    setloading(true);
    await api_init_post("assignbids", { bid_id: id, bid }, reload, seterror);
    setloading(false);
  }
}

async function cancelAssign(id, type, setloading, seterror, reload) {
  if (window.confirm("Confirm Cancel")) {
    setloading(true);
    await api_init_post(
      "cancelassign?type=" + type,
      { bid_id: id },
      reload,
      seterror
    );
    setloading(false);
  }
}

export { getBids, getCatogeryBids, createBid, confirmBid, cancelAssign };
