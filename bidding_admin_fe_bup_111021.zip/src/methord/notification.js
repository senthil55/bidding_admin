import { api_init_get, api_init_put } from "../module/api_init";

async function getNoti(settableitem, setitem, seterror, v) {
  // settableitem([]);
  // setitem([]);
  var data = [];
  var t_data = [];
  await api_init_get("noti?" + v, (v) => (data = v), seterror);
  for (let i = 0; i < data.length; i++) {
    t_data.push([
      [data[i].title, data[i].desc],
      [data[i].created.split("G")[0]],
    ]);
  }
  settableitem(t_data);
  setitem(data);
  return 0;
}

async function makeNotificationseen(id) {
  api_init_put(
    "category",
    { seen: true },
    () => {},
    () => {}
  );
}

export { getNoti, makeNotificationseen };
