import React from "react";
import { baseUrlimgkyc } from "../module/api_init";

function MemberDetailsPopup({ members, i, close, buttons, error }) {
  console.log(members);
  return (
    <div
      className="cm1_memeber_popup"
      style={{ display: i !== null ? "flex" : "none" }}
    >
      <div className="cm1_memeber_body">
        <div className="cm1_mb1_a">
          <div className="cm1_mb1_aa">
            Memebr
            <div style={{ cursor: "pointer" }} onClick={close}>
              X
            </div>
          </div>
          {i === null ? (
            ""
          ) : (
            <React.StrictMode>
              <div className="cm1_mb1_abz">
                <div className="cm1_mb1_ab">
                  <div className="cm1_mb1_aba">Profile</div>
                  <div className="cm1_mb1_abb">
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Name</div>
                      <div className="cm1_mb1_abbab">{members[i].name}</div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Username</div>
                      <div className="cm1_mb1_abbab">
                        {members[i].user_name}
                      </div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Phone</div>
                      <div className="cm1_mb1_abbab">{members[i].phone}</div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Email</div>
                      <div className="cm1_mb1_abbab">
                        {members[i].email}
                        {members[i].email !== null
                          ? members[i].email_verifyed
                            ? " - Verifide"
                            : " - Not Verifide"
                          : null}
                      </div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Langage</div>
                      <div className="cm1_mb1_abbab">{members[i].lang}</div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Status</div>
                      <div className="cm1_mb1_abbab">
                        {members[i].status === "b"
                          ? "Blocked"
                          : members[i].status === "a"
                          ? "Active"
                          : members[i].status === "f"
                          ? "Freezed"
                          : members[i].status === "d"
                          ? "Note Aproved"
                          : "None"}
                      </div>
                    </div>
                    <div className="cm1_mb1_abbb" />
                  </div>
                </div>
                <div className="cm1_mb1_ab">
                  <div className="cm1_mb1_aba">Location</div>
                  <div className="cm1_mb1_abb">
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">State</div>
                      <div className="cm1_mb1_abbab">{members[i].state}</div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">District</div>
                      <div className="cm1_mb1_abbab">{members[i].district}</div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Town</div>
                      <div className="cm1_mb1_abbab">{members[i].town}</div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Pin Code</div>
                      <div className="cm1_mb1_abbab">{members[i].pincode}</div>
                    </div>
                    <div className="cm1_mb1_abbb" />
                  </div>
                </div>
                <div className="cm1_mb1_ab">
                  <div className="cm1_mb1_aba">Bussnuss</div>
                  <div className="cm1_mb1_abb">
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Catogory</div>
                      <div className="cm1_mb1_abbab">{members[i].catogory}</div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Orgenisation Name</div>
                      <div className="cm1_mb1_abbab">{members[i].org_name}</div>
                    </div>
                    <div className="cm1_mb1_abba">
                      <div className="cm1_mb1_abbaa">Address</div>
                      <div className="cm1_mb1_abbab">{members[i].address}</div>
                    </div>
                    <div className="cm1_mb1_abbb" />
                  </div>
                </div>
                <div className="cm1_mb1_ab">
                  <div className="cm1_mb1_aba">KYC Document</div>
                  <div className="cm1_mb1_abb">
                    <img
                      height="300"
                      src={baseUrlimgkyc + members[i].kyc_document}
                    />
                  </div>
                </div>
              </div>
              <div className="cm1_error">{error}</div>
              <div className="cm1_mb1_ac">{buttons}</div>
            </React.StrictMode>
          )}
        </div>
      </div>
    </div>
  );
}
export default MemberDetailsPopup;
