function Raiting({ r }) {
  return r;
}

export default Raiting;
